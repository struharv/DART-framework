#!/bin/bash

sudo /home/pi/sender/final_sender eth0 10 1 101 
sudo /home/pi/sender/final_sender eth0 10 2 102

sleep 2 
sudo tshark -i eth0 -f "udp" -w /home/pi/sender/mycaptures.pcap -a duration:960 
