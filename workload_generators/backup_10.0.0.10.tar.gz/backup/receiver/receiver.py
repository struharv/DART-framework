import socket
import logging



TCP_IP='10.0.0.5'
TCP_PORT=5005
BUFFER_SIZE= 20
i=0

s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
s.bind((TCP_IP,TCP_PORT))
s.listen(5)

conn, addr= s.accept()
print 'Connection address: ', addr


while i<10:
	
	data=conn.recv(BUFFER_SIZE)
	if not data: break
	print "received data:", data
	conn.send(data)
        i=i+1
conn.send("disconnect") 
conn.close()
