#!/bin/bash
sleep 30
sudo /home/pi/sender/final_sender eth0 85 4 104 40
