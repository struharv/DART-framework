#!/bin/bash
sleep 12
while true
	do
		sudo /home/pi/sender/final_sender eth0 10 1 101 1440>>sender.txt
 
#		sleep 5
#		sudo /home/pi/sender/final_sender eth0 10  3  102
#		sleep 5
#		sudo /home/pi/sender/final_sender eth0 10  2 103
#		sleep 5
#		sudo /home/pi/sender/final_sender eth0 10  4 104
#		sleep 5
		#sleep 44
#		sleep 7
#	done
