#!/bin/bash
sleep 90

sudo /home/pi/sender/final_sender eth0 50 5 102 40

