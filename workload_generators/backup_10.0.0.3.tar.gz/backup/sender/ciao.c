#include <stdio.h>
#include <unistd.h>

int main(void){
printf("ciao");
return 0;
}
