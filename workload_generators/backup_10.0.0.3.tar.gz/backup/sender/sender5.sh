#!/bin/bash
sleep 45
sudo /home/pi/sender/final_sender eth0 40 1 102 40

