import socket

TCP_IP='10.0.0.5'
TCP_PORT= 5005
BUFFER_SIZE= 1024
MESSAGE= "HELLO"
print MESSAGE

s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
print "created socket"
s.connect((TCP_IP,TCP_PORT))
print "connected" 
while True:
	print "sending"
	s.send(MESSAGE)
	data=s.recv(BUFFER_SIZE)
	print "received data: ", data

	if data=="disconnect": 
		break
	
s.close()
