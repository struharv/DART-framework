#!/bin/bash
sleep 1
sudo /home/pi/sender/final_sender eth0 25 1 101 40
