#!/bin/bash
sleep 60
sudo /home/pi/sender/final_sender eth0 30 2 102 40
