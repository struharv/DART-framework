#!/bin/bash
sleep 15
sudo /home/pi/sender/final_sender eth0 90 3 103 40
