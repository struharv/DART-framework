#!/bin/bash
sleep 75
sudo /home/pi/sender/final_sender eth0 70 0 104 40

